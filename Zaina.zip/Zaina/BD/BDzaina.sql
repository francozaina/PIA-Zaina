USE master;
GO

-- Crear la base de datos
CREATE DATABASE zaina;
GO

-- Utilizar la base de datos
USE zaina;
GO

-- Crear la tabla de Preguntas
CREATE TABLE Preguntas (
  Pregunta_id INT PRIMARY KEY IDENTITY(1,1),
  Pregunta VARCHAR(255) NOT NULL,
  Opcion1 VARCHAR(255) NOT NULL,
  Opcion2 VARCHAR(255) NOT NULL,
  Opcion3 VARCHAR(255) NOT NULL,
  Opcion4 VARCHAR(255) NOT NULL,
  Respuesta_correcta VARCHAR(255) NOT NULL,
  Fecha_creacion DATE NOT NULL
);

-- Insertar datos de prueba en la tabla Preguntas
INSERT INTO Preguntas (Pregunta, Opcion1, Opcion2, Opcion3, Opcion4, Respuesta_correcta, Fecha_creacion)
VALUES ('�Cu�l es la capital de Francia?', 'Par�s', 'Roma', 'Londres', 'Madrid', 'Par�s', GETDATE()),
       ('�En qu� a�o se descubri� Am�rica?', '1492', '1776', '1812', '1901', '1492', GETDATE()),
       ('�Cu�l es el r�o m�s largo del mundo?', 'Amazonas', 'Nilo', 'Yangts�', 'Misisipi', 'Amazonas', GETDATE()),
       ('�Cu�l es el planeta m�s grande del sistema solar?', 'J�piter', 'Saturno', 'Urano', 'Neptuno', 'J�piter', GETDATE()),
       ('�Cu�l es el oc�ano m�s grande?', 'Pac�fico', 'Atl�ntico', '�ndico', '�rtico', 'Pac�fico', GETDATE());

-- Crear la tabla de Respuestas
CREATE TABLE Respuestas (
  Respuesta_id INT PRIMARY KEY IDENTITY(1,1),
  User_id INT NOT NULL,
  Respuesta_seleccionada VARCHAR(255) NOT NULL,
  Es_respuesta_correcta BIT NOT NULL,
  Fecha_creacion DATE NOT NULL
);

-- Insertar datos de prueba en la tabla Respuestas
INSERT INTO Respuestas (User_id, Respuesta_seleccionada, Es_respuesta_correcta, Fecha_creacion)
VALUES (1, 'Par�s', 1, GETDATE()),
       (1, '1776', 0, GETDATE()),
       (2, 'Nilo', 1, GETDATE()),
       (2, 'Saturno', 0, GETDATE()),
       (3, 'Pac�fico', 1, GETDATE());