import sql from 'mssql';
import configDB from '../../DB.js';
import 'dotenv/config'

export class PreguntaService {
  
    GetAllPreguntas = async (filtroPalabraClave, ordenFechaCreacion) => {
        try {
          const conn = await sql.connect(configDB);
          let query = 'SELECT * FROM Preguntas';
          if (filtroPalabraClave) {
            query += ` WHERE Pregunta LIKE '%${filtroPalabraClave}%'`;
          }
          if (ordenFechaCreacion) {
            query += ` ORDER BY Fecha_creacion ${ordenFechaCreacion.toUpperCase()}`;
          }
          const results = await conn.request().query(query);
          return results.recordset;
        } catch (error) {
          console.log(error);
          return null;
        }
      };

    GetRandomPregunta = async () => {
    try {
      const conn = await sql.connect(configDB);
      const results = await conn.request().query('SELECT TOP 1 * FROM Preguntas ORDER BY NEWID()');
      return results.recordset[0];
    } catch (error) {
      console.log(error);
      return null;
    }
  };
  
  
    UpdatePregunta = async (pregunta, preguntaId) => {
    try {
      const pool = await sql.connect(configDB);
      const anteriorPregunta = await this.GetPreguntaById(preguntaId);
      const result = await pool
        .request()
        .input('pId', sql.Int, preguntaId)
        .input('pPregunta', sql.VarChar, pregunta.Pregunta || anteriorPregunta.Pregunta)
        .input('pOpcion1', sql.VarChar, pregunta.Opcion1 || anteriorPregunta.Opcion1)
        .input('pOpcion2', sql.VarChar, pregunta.Opcion2 || anteriorPregunta.Opcion2)
        .input('pOpcion3', sql.VarChar, pregunta.Opcion3 || anteriorPregunta.Opcion3)
        .input('pOpcion4', sql.VarChar, pregunta.Opcion4 || anteriorPregunta.Opcion4)
        .input('pRespuestaCorrecta', sql.Int, pregunta.RespuestaCorrecta || anteriorPregunta.RespuestaCorrecta)
        .query('UPDATE Preguntas SET Pregunta = @pPregunta, Opcion1 = @pOpcion1, Opcion2 = @pOpcion2, Opcion3 = @pOpcion3, Opcion4 = @pOpcion4, Respuesta_correcta = @pRespuestaCorrecta WHERE Pregunta_id = @pId');

      console.log(result);
      return result.recordset;
    } catch (error) {
      console.log(error);
      return null;
    }
  };

  GetPreguntaById = async (preguntaId) => {
    try {
      const conn = await sql.connect(configDB);
      const results = await conn
        .request()
        .input('pId', sql.Int, preguntaId)
        .query('SELECT * FROM Preguntas WHERE Pregunta_id = @pId');

      console.log(results.recordset);
      return results.recordset[0];
    } catch (error) {
      console.log(error);
      return null;
    }
  };

  AddPregunta = async (pregunta) => {
    const error = 'Falta un atributo';
    if (!pregunta.Pregunta || !pregunta.Opcion1 || !pregunta.Opcion2 || !pregunta.Opcion3 || !pregunta.Opcion4 || !pregunta.RespuestaCorrecta) {
      return error;
    }
    const fechaActual = new Date().toISOString().replace(/T/, ' ').replace(/\..+/, '');
    try {
      const connection = await sql.connect(configDB);
      const results = await connection
        .request()
        .input('pPregunta', sql.VarChar, pregunta.Pregunta)
        .input('pfechaActual', sql.VarChar, fechaActual)
        .input('pOpcion1', sql.VarChar, pregunta.Opcion1)
        .input('pOpcion2', sql.VarChar, pregunta.Opcion2)
        .input('pOpcion3', sql.VarChar, pregunta.Opcion3)
        .input('pOpcion4', sql.VarChar, pregunta.Opcion4)
        .input('pRespuestaCorrecta', sql.Int, pregunta.RespuestaCorrecta)
        .query('INSERT INTO Preguntas (Pregunta, Opcion1, Opcion2, Opcion3, Opcion4, Respuesta_correcta, Fecha_creacion) VALUES (@pPregunta, @pOpcion1, @pOpcion2, @pOpcion3, @pOpcion4, @pRespuestaCorrecta, @pfechaActual)');
      console.log(results);
    } catch (error) {
      console.log(error);
    }
  };
  
  DeletePregunta = async (preguntaId) => {
    try {
      const conn = await sql.connect(configDB);
      const results = await conn
        .request()
        .input('pId', sql.Int, preguntaId)
        .query('DELETE FROM Preguntas WHERE Pregunta_id = @pId');
      console.log(results);
    } catch (error) {
      console.log(error);
    }
  };

  

  

  
}