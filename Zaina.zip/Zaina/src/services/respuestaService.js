import sql from 'mssql';
import configDB from '../../DB.js';
import 'dotenv/config'
import { PreguntaService } from './PreguntaService.js';

const preguntaService = new PreguntaService();

export class RespuestaService {
  CreateRespuesta = async (respuesta) => {
    const idPregunta = respuesta.Pregunta_id;
    let esRespuestaCorrecta = false;
    const fechaActual = new Date().toISOString().replace(/T/, ' ').replace(/\..+/, '');
    try {
      const connection = await sql.connect(configDB);
      const pregunta = await preguntaService.GetPreguntaById(idPregunta);

      if (pregunta.Respuesta_correcta === respuesta.Respuesta_seleccionada) {
        esRespuestaCorrecta = true;
      }

      const results = await connection
        .request()
        .input('pResSel', sql.Int, respuesta.Respuesta_seleccionada)
        .input('pFecha', sql.VarChar, fechaActual)
        .input('pEsResCorrecta', sql.Bit, esRespuestaCorrecta)
        .input('pPregId', sql.Int, idPregunta)
        .input('pUserId', sql.Int, respuesta.UserId)
        .query('INSERT INTO Respuestas (UserId, RespuestaSeleccionada, FechaCreacion, EsRespuestaCorrecta, PreguntaId) VALUES (@pUserId, @pResSel, @pFecha, @pEsResCorrecta, @pPregId)');

      console.log(results);
    } catch (error) {
      console.log(error);
    }
  };
}