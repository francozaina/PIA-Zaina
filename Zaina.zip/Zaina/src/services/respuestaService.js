import sql from 'mssql';
import configDB from '../../DB.js';
import 'dotenv/config'
import { PreguntaService } from './PreguntaService.js';

const preguntaService = new PreguntaService();

export class RespuestaService {
  CreateRespuesta = async (respuesta) => {
    const idPregunta = respuesta.Pregunta_id;
    let esRespuestaCorrecta = false;
    const fechaActual = new Date().toISOString().replace(/T/, ' ').replace(/\..+/, '');
    try {
      const connection = await sql.connect(configDB);
      const pregunta = await preguntaService.GetPreguntaById(idPregunta);

      if (pregunta.Respuesta_correcta === respuesta.Respuesta_seleccionada) {
        esRespuestaCorrecta = true;
      }

      const results = await connection
        .request()
        .input('pResSel', sql.VarChar, respuesta.Respuesta_seleccionada)
        .input('pFecha', sql.VarChar, fechaActual)
        .input('pEsResCorrecta', sql.Bit, esRespuestaCorrecta)
        .input('pPregId', sql.Int, idPregunta)
        .input('pUserId', sql.Int, respuesta.UserId)
        .query('INSERT INTO Respuestas (User_id, Respuesta_seleccionada, Fecha_creacion, Es_respuesta_correcta) VALUES (@pUserId, @pResSel, @pFecha, @pEsResCorrecta)');

      console.log(results);
    } catch (error) {
      console.log(error);
    }
  };
}